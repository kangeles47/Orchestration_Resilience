function [lfm,Dl,Sax,Say]=time_based_assessment(T1x,T1y,num_int,PGAx,PGAy,SA1x,SA1y,SA02x,SA02y)


Tm=(T1x+T1y)/2;

if Tm<=1
    Sa_min=0.05;
else
    Sa_min=0.05/Tm;
end

l=0.0002;

flag=1;

[Sa_max,~]=haz_curve_l(Tm,l,Sa_min,PGAx,PGAy,SA1x,SA1y,SA02x,SA02y,flag);

Interval=(Sa_max-Sa_min)/num_int;

Sa=Sa_min:Interval:Sa_max;

flag=0;

Sa_m=mean([Sa(1:end-1);Sa(2:end)]);

[~,lf]=haz_curve_l(Tm,l,Sa,PGAx,PGAy,SA1x,SA1y,SA02x,SA02y,flag);
[~,lfm]=haz_curve_l(Tm,l,Sa_m,PGAx,PGAy,SA1x,SA1y,SA02x,SA02y,flag);

Dl=lf(1:end-1)-lf(2:end);

flag=1;

[Sax,~]=haz_curve_l(T1x,lfm,Sa_min,PGAx,PGAy,SA1x,SA1y,SA02x,SA02y,flag);

[Say,~]=haz_curve_l(T1y,lfm,Sa_min,PGAx,PGAy,SA1x,SA1y,SA02x,SA02y,flag);

end