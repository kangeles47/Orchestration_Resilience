function [x_disp,y_disp,mean_drift_ratios,mean_accel,B_SD,B_FA,B_FV,B_RD]=InitResponseModule(FrameObjNames,units,FilePathResponse,elev,Fj,num_int,T1,hj,g,PGAx,PGAy,SA1x,SA1y,lfm,Frame_type)
%% Initialization Script for MATLAB side of the Response Module:

%This function combines MATLAB scripts which conduct analyses using the
%ELFM (Equivalent Lateral Force Method) for num_int number of intensities,
%as defined in the Hazard Module. Displacements are obtained at the
%centroid of each floor for loading in the x and y directions. Corrections
%are implemented as per FEMA Simplified Analysis Procedures. 

%Contents of script:
%(1)ResponseSapAPI function--> Finds x and y centroid of the structure, applies
%ELFM, calculates structure's response

%(2) mean_dispersion function -->
%% Input/Output for ResponseSapAPI

%Input:
%FrameObjNames - list of names of frame members from HazardSapAPI.m
%units - same as in HazardSapAPI.m
%FilePathResponse - this will be the name of that from the HazardSapAPI.m model at
%the end
%elev - vector of elevations beginning from z=0 to roof
%Fj - matrix of ELFs for the num_int number of intensities specified in the
%Hazard Module
%num_int - number of intervals as defined in previous module

%Note: This script was modified so that we can run all iterations of our
%ELFs without having to open and close SAP each time (saves time)

[x_disp,y_disp,Joint_elev,JointNames]=ResponseSapAPI(FrameObjNames,units,FilePathResponse,elev,Fj,num_int);

%Outputs: Ux,Uy --> nx1 vectors of displacements at the centroid of each floor for the x and y directions for
%each set of ELFs. 

%Joint_elev: z-coordinate of respective joint specified in JointNames

%JointNames: Names of newly defined points at floor centroids for ELFM

%% Input/Output for median_dispersions function:
%Calculation of Median responses and Dispersions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Input%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%N: number of stories
%T1: fundamental period of structure(in sec) in x and y direction respectively
%Vy: in kips, estimated yield base shear from Nonlinear Static Analysis,in x and y direction respectively
%hj: height(in ft) of each floor
%g: acceleration of gravity(determines the units of displacement and of
%velocity)
%PGA: Peak ground aceeleration in g
%Sa_1: Spectral acceleration at a period of 1.0 sec,in g
%Gamma: modal participation factors of the fundamental mode,in x and y direction respectively
%Frame type: Braced, Moment or Wall
%disp_x,disp_y Median displacement in x and y direction(from Linear analysis/vectors:from down to upper floors)

%For calculating PGA and Sa_1 variables:
%These are just here so that we have actual values from USGS for Chicago: 
PGA=xlsread('total.csv');
PGAx=PGA(1,3:18);
PGAy=PGA(2,3:18);

SA1=xlsread('total_SA1.csv');
SA1x=SA1(1,3:18);
SA1y=SA1(2,3:18);

%Initialize variables:
mean_drift_ratios=zeros(length(hj),num_int*2);
mean_accel=zeros(length(hj),num_int*2);
B_SD=zeros(1,num_int*2); %From what it seems our output is a 1x2 vector
B_FA=zeros(1,num_int*2);
B_FV=zeros(1,num_int*2);
B_RD=zeros(1,num_int*2);

for j=1:num_int
    PGA=interp1(PGAy,PGAx,lfm(j));
    Sa_1=interp1(SA1y,SA1x,lfm(j));
    disp_x=x_disp(:,j);
    disp_y=y_disp(:,j);
    [m_drift_ratios,m_accel,b_SD,b_FA,b_FV,b_RD]=median_dispersions(T1,hj,g,PGA,Sa_1,Frame_type,disp_x,disp_y);
    if j==1
        mean_drift_ratios(:,j:j*2)=m_drift_ratios;
        mean_accel(:,j:j*2)=m_accel;
        B_SD(:,j:j*2)=b_SD;
        B_FA(:,j:j*2)=b_FA;
        B_FV(:,j:j*2)=b_FV;
        B_RD(:,j:j*2)=b_RD;
    else
        mean_drift_ratios(:,2*j-1:j*2)=m_drift_ratios;
        mean_accel(:,2*j-1:j*2)=m_accel;
        B_SD(:,2*j-1:j*2)=b_SD;
        B_FA(:,2*j-1:j*2)=b_FA;
        B_FV(:,2*j-1:j*2)=b_FV;
        B_RD(:,2*j-1:j*2)=b_RD;
    end


end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Output%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculation of Median responses and Dispersions for x and y direction



end